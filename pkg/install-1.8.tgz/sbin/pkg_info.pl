#!/usr/bin/perl

# Minimal pkg_info, similar to OpenBSD's without all the options.
# Completely superfluous on OpenBSD, but can be used on Linux or macOS
# in conjunction with install.pl.
# Written 5 October 2025 by Jim Lippard
# Modified 4 January 2026 by Jim Lippard to remove & on subroutine calls.
# Modified 2 May 2026 by Jim Lippard for minor improvements.
# Modified 17 May 2026 by Jim Lippard to not use bareword filehandles.
# Modified 1 July 2026 by Jim Lippard after Claude Opus 4.8 review to
#    fix minor issues and make error checking more robust.

use strict;
use warnings;

my $PKG_DIR = '/var/db/pkg';

my ($arg, $package, @all_packages, @found_packages);

if ($#ARGV == -1) {
    list_all_brief();
    exit;
}

@all_packages = get_all_packages();

foreach $arg (@ARGV) {
    $package = find_package ($arg, @all_packages);
    push (@found_packages, $package) if ($package);
}

die "No valid packages specified.\n" unless (@found_packages);

foreach $package (@found_packages) {
    show_package_desc ($package);
}

# Subroutine to get all packages.
sub get_all_packages {
    my (@all_packages);

    opendir (my $dir_fh, $PKG_DIR) || die "Cannot open $PKG_DIR for reading file list. $!\n";
    @all_packages = grep { !/^\.{1,2}$/ && -d "$PKG_DIR/$_" } readdir ($dir_fh);
    closedir ($dir_fh);

    return (@all_packages);
}

# Subroutine to find a matching package name.
sub find_package {
    my ($package_string, @all_packages) = @_;
    my $package;

    foreach $package (@all_packages) {
	return ($package) if ($package eq $package_string);
	if ($package =~ /^\Q$package_string\E-\d/) { # must match up to a version number, not just any substring.
	    return ($package);
	}
    }

    print "Did not find matching package for \"$package_string\".\n";
    return 0;
}

sub list_all_brief {
    my (@all_packages, $package, $package_name,
	$one_liner);

    opendir (my $dir_fh, $PKG_DIR) || die "Cannot open $PKG_DIR for reading file list. $!\n";
    @all_packages = grep (!/^\.{1,2}$/, readdir ($dir_fh));
    closedir ($dir_fh);

    foreach $package (sort @all_packages) {
	next unless (-d "$PKG_DIR/$package");
	$package_name = '';
	my $pkg_fh;
	if (!open ($pkg_fh, '<', "$PKG_DIR/$package/+CONTENTS")) {
	    warn "Skipping $package: Cannot open +CONTENTS. $!\n";
	    next;
	}
	while (<$pkg_fh>) {
	    if (/^\@name (.*)$/) {
		$package_name = $1;
	    }
	}
	close ($pkg_fh);
	die "Cannot find \"\@name\" in +CONTENTS for package $package.\n" unless (defined ($package_name) && length ($package_name) > 0);

	my $desc_fh;
	if (!open ($desc_fh, '<', "$PKG_DIR/$package/+DESC")) {
	    warn "Skipping $package: Cannot open +DESC. $!\n";
	    next;
	}
	$one_liner = <$desc_fh>;
	$one_liner = '' unless defined ($one_liner);
	chomp ($one_liner);
	close ($desc_fh);

	printf "%-19s %s\n", $package_name, $one_liner;
    }
}

sub show_package_desc {
    my ($package) = @_;
    my ($one_liner);

    unless (-d "$PKG_DIR/$package") {
        warn "Skipping $package: not a package directory.\n";
        return;
    }
    open (my $fh, '<', "$PKG_DIR/$package/+DESC") || die "Cannot open +DESC for package $package. $!\n";
    $one_liner = <$fh>;
    $one_liner = '' unless defined ($one_liner);
    chomp ($one_liner);
    print "Information for inst:$package\n\n";
    print "Comment:\n$one_liner\n\nDescription:\n";
    while (<$fh>) {
	chomp;
	print "$_\n";
    }
    close ($fh);

    # Just to be identical to pkg_info.
    print "\n\n";
}
