#!/usr/bin/perl
# Script to package up configs or binaries for installation across multiple
# servers, sign them with signify, and distribute them to installation
# locations, where they will be installed by install.pl after shutdown into
# single user mode where immutability can be turned off.
#
# Note: installing certificates requires manually unlocking the etcrare
#   group before running install.pl [No longer true, syslock groups fix that.]
#
# Written 30-31 January to 4 February 2022 by Jim Lippard.
# Modified 8 February 2022 by Jim Lippard to require rrsync on the other
#    end, which forces all of the copied files to go into the /var/install
#    directory.
# Modified 14 February 2022 by Jim Lippard so that find_package will use gt
#    instead of > to select the latest version by version string.
# Modified 16 February 2022 by Jim Lippard to add support for certificate
#    distribution.
# Modified 12 May 2022 by Jim Lippard to add support for external IP address
#    changes.
# Modified 27 January 2023 by Jim Lippard to manually correct permissions
#    on pf.conf for external IP address changes, since cp -p doesn't preserve
#    them.
# Modified 14 March 2023 by Jim Lippard to support file versons with flavors,
#    like emacs-20.8p0-no_x11.tgz.
# Modified 18 August 2023 by Jim Lippard to make the manual correction of
#    pf.conf permissions from 27 January 2023 actually work.
# Modified 28 December 2023 by Jim Lippard to add OpenBSD minimum version
#    on signify key (same check as in install.pl).
# Modified 2 January 2024 by Jim Lippard to use File::Copy instead of system command; cp
#    preserves source permissions and copy uses destination umask.
# Modified 4 January 2024 by Jim Lippard to use pledge/unveil. Of limited value.
# Modified 5 January 2024 by Jim Lippard to rework signify signature
#    validation in pledge/unveil environment and be more robust.
# Modified 7 January 2024 by Jim Lippard to support annual keys
#    and new OpenBSD pkg_add "-pkg" requirement in key name.
# Modified 14 March 2024 by Jim Lippard to improve ip-address change process.
# Modified 23 March 2024 by Jim Lippard to add -6 and -4 options.
# Modified 24 April 2024 by Jim Lippard to use OpenBSD::MkTemp.
# Modified 27 July 2024 by Jim Lippard to use Signify module.
# Modified 20 November 2024 by Jim Lippard to add SYSLOCKGROUPS
#    array to configs, to send signed list of syslock groups to destination,
#    for plain and custom files. For packages, we just assume everything
#    goes into /usr/local or /etc ("local" and "etc" syslock group).
# Modified 4 January 2025 by Jim Lippard to add -p (prior year key) to
#    sign with last year's key (e.g., to distribute new key after year
#    changes!).
# Modified 27 January 2025 by Jim Lippard to get key name from host domain
#    name.
# Modified 27-29 January 2025 by Jim Lippard to move from static hash to
#    parsed config file, add -c config option.
# Modified 2 February 2025 by Jim Lippard to add unveil: to config file for
#    custom types, standardize subroutine naming for custom-related
#    subroutines, add %CUSTOM_PLEDGE hash, and remove most special-casing.
#    Added $HOST as another variable that can be used in the config file,
#    source path for ip-address only. $SIGNIFY_PUB_KEY and $SIGNIFY_PUB_KEY_NEXT
#    can already be used for file or dest.
# Modified 4 February 2025 by Jim Lippard to add unveil-exec: to config
#    file for custom types; unveil: now unveils with r only, use unveil-exec:
#    for rx. Make all system calls use argument list to avoid shell.
# Modified 6 February 2025 by Jim Lippard to re-do custom processing and
#    put into subroutines.
# Modified 7 February 2025 by Jim Lippard to add custom-vars: for custom file
#    types, to pass variables and values from config for use by custom
#    file processing. Fix bug in macro expansion. Spaces are now allowed in
#    values of custom-vars and macros.
# Modified 10 February 2025 by Jim Lippard to add more validation on config
#    parsing and make syslock groups optional.
# Modified 11 February 2025 by Jim Lippard to make dest: prohibited for
#    packages.
# Modified 16 February 2025 by Jim Lippard to fix bugs (can't check for
#    file/dir existence before unveiling if unveiling has already begun;
#    had double declaration of a variable passed as parameter to doas).
# Modified 26 April 2025 by Jim Lippard to fix custom pledge for ip-address
#    and to use getaddrinfo/getnameinfo instead of inet_aton/inet_ntoa.
# Modified 12 May 2025 by Jim Lippard to allow overriding of old IP in
#    ip-address if the DNS record is inaccurate, fix bug in DNS lookup.
# Modified 22 June 2025 by Jim Lippard to allow each wan to have a separate
#    DNS record.
# Modified 2 August 2025 by Jim Lippard to do better version checks (> is
#    preferred to gt).
# Modified 8 August 2025 by Jim Lippard to add -h host option and -d debug option.
# Modified 13 August 2025 by Jim Lippard to take another stab at version comparisons,
#    for OpenBSD package version formats.
# Modified 14 September 2025 by Jim Lippard to convert 'all' to hosts list
#    during config parsing and to support 'all except' followed by a hosts
#    list. First step towards supporting distribution to multiple operating
#    systems, in the future might allow defining host groups.
# Modified 22 September 2025 by Jim Lippard to clean up some regexes and fix bug in
#    processing multiple files.
# Modified 24 September 2025 by Jim Lippard to complain if -h leads to no matches.
# Modified 2 October 2025 by Jim Lippard to change $vv variable name to
#    $v_epoch (OpenBSD Makefile term).
# Modified 9 November 2025 by Jim Lippard to unveil /dev/null for Signify.pm.
# Modified 13 November 2025 by Jim Lippard to not allow OpenBSD signing
#    keys if not on OpenBSD.
# Modified 1 January 2026 by Jim Lippard to fix bug in verify_signature
#    when using secondary keys (pubkey dir no longer recorded).
# Modified 3 January 2026 by Jim Lippard to check for existence of current
#    year signing key and warn about next year's signing key 30 days in
#    advance.
# Modified 4 January 2026 by Jim Lippard to remove & from subroutine calls.
# Modified 4 March 2026 by Jim Lippard to remove tmppath pledge.
# Modified 20 April 2026 by Jim Lippard to fix version comparison typo
#    and remove dead code sign_package (now done by Signify).
# Modified 21 April 2026 by Jim Lippard to add -k (key) option and config
#    file options for pkg-dir and default-signing-key. If a non-standard
#    format key is used for plain or custom files, the user will be warned
#    and prompted to continue. Packages can be signed by any <domain>-<year>-pkg
#    key for which the public key is in /etc/signify (this script doesn't
#    sign packages but expects them to be signify-signed, e.g., with OpenBSD's
#    pkg_sign or manually with signify).

use strict;
use Archive::Tar;
use File::Basename qw(basename dirname fileparse);
use File::Copy qw(copy cp);
use File::Path qw(rmtree);
use Getopt::Std;
use IO::Uncompress::Gunzip;
use POSIX qw(strftime);
use Signify qw(signify_error);
use Sys::Hostname;
use if $^O eq "openbsd", "OpenBSD::MkTemp", qw( mkdtemp );
use if $^O eq "openbsd", "OpenBSD::Pledge";
use if $^O eq "openbsd", "OpenBSD::Unveil";


my $VERSION = 'distribute.pl version 1.0 of 21 April 2026.';

my $INSTALL_DIR = '/var/install';
my $PKG_DIR = '/usr/ports/packages/amd64/all';

# plain: The file goes, as is, to individual hosts.
# package: It's a signed package, it goes, as is, to individual hosts.
# custom: There's a module to deal with special processing, the file
#   may be different for each host and the DEST may need to be specified
#   if the file extracts into the root dir or install dir.
my @TYPES = ('plain', 'custom', 'package');

# Suffix for rsync host name (default for v4; add v6 when v6
# is required for Quantum Fiber IP address change).
my $RSYNC_HOST_SUFFIXv4 = '-distribute';
my $RSYNC_HOST_SUFFIXv6 = '-distributev6';

my $MKDIR = '/bin/mkdir';
my $MKTEMP = '/usr/bin/mktemp';
my $RSYNC = '/usr/local/bin/rsync';
my $SIGNIFY = '/usr/bin/signify';
my $STTY = '/bin/stty';
my $UNAME = '/usr/bin/uname';

my ($year) = (localtime (time()))[5];
$year += 1900;
my $prev_year = $year - 1;
my $next_year = $year + 1;

my $HOSTNAME = hostname();
my (@HOSTNAME_ARRAY) = split (/\./, $HOSTNAME);
my $DOMAINNAME = pop (@HOSTNAME_ARRAY);
$DOMAINNAME = pop (@HOSTNAME_ARRAY) . '.' . $DOMAINNAME;

my $SIGNIFY_PUB_KEY_DIR = '/etc/signify';
my $SIGNIFY_KEY_NAME = "$DOMAINNAME-$year-pkg";
my $SIGNIFY_SEC_KEY = "$SIGNIFY_PUB_KEY_DIR/$SIGNIFY_KEY_NAME.sec";
my $SIGNIFY_PUB_KEY = "$SIGNIFY_PUB_KEY_DIR/$SIGNIFY_KEY_NAME.pub";
my $PRIOR_SIGNIFY_KEY_NAME = "$DOMAINNAME-$prev_year-pkg";
my $PRIOR_SIGNIFY_SEC_KEY = "$SIGNIFY_PUB_KEY_DIR/$PRIOR_SIGNIFY_KEY_NAME.sec";
my $PRIOR_SIGNIFY_PUB_KEY = "$SIGNIFY_PUB_KEY_DIR/$PRIOR_SIGNIFY_KEY_NAME.pub";
# next for distributing, not for signing (yet).
my $SIGNIFY_KEY_NEXT_NAME = "$DOMAINNAME-$next_year-pkg";
my $SIGNIFY_PUB_KEY_NEXT = "$SIGNIFY_PUB_KEY_DIR/$SIGNIFY_KEY_NEXT_NAME.pub";
my $SIGNIFY_MIN_YEAR = $prev_year;
my $current_openbsd;
if ($^O eq 'openbsd') {
    $current_openbsd = `$UNAME -a`;
    $current_openbsd =~ s/^OpenBSD [\w\.]+ (\d+)\.(\d+) .*$/$1$2/;
    $current_openbsd--;
}
else {
    $current_openbsd = 'not-openbsd';
}
    
my $OPENBSD_MIN_VERSION = "$current_openbsd";

my $CONFIG_FILE = '/etc/distribute.conf';

my %CONFIG; # was constant, now is generated by parse_config
my @HOSTS; # was constant, now generated by parse_config

### For custom files. Add any new required pledges to the hash
### %CUSTOM_PLEDGE for the , they will only be pledged when that
### file is being distributed.

my @custom_pledges;

# for ip-address:
# fattr for copy of pf.conf to preserve perms, doesn't seem to work
my %CUSTOM_PLEDGE = ('ip-address' => [ 'dns', 'fattr' ] );

### Variables.

my (%opts, $use_v6, $use_prev_year_key, $rsync_host_suffix, $config_file,
    $host_option, @selected_hosts, $debug_flag);

my ($arg, @args, $file, @files, @process_hosts, $package_path,
    %host_package_path, %host_package_files,
    $host, $date, $temp_dir, $temp_file,
    $dest_path, $dest_dir, $dest_file,
    $have_fake_dir,
    $signify_passphrase, @files_to_ship_and_remove, @rsync_file_list,
    @install_packages);

# Signing key variables (set after config parsing and option processing)
my ($signing_sec_key, $signing_pub_key, $signing_key_name);

# Hash of arrays, one per host.
my %syslock_groups;

# Signify errors.
my @errors;

### Main program.

# Get options first.
getopts ('46pdVc:h:k:', \%opts) || exit;

# -V version
if ($opts{'V'}) {
    print "$VERSION\n";
    exit 0;
}

# -4 default and doesn't really do anything.
if ($opts{'4'} && $opts{'6'}) {
    die "-4 and -6 are mutually exclusive.\n";
}

if ($opts{'6'}) {
    $use_v6 = 1;
    $rsync_host_suffix = $RSYNC_HOST_SUFFIXv6;
}
else {
    $use_v6 = 0;
    $rsync_host_suffix = $RSYNC_HOST_SUFFIXv4;
}

if ($opts{'p'}) {
    $use_prev_year_key = 1;
}

# -k custom key option
my $custom_key_option = $opts{'k'};

# -k and -p are mutually exclusive
if ($custom_key_option && $use_prev_year_key) {
    die "-k (custom key) and -p (prior year key) are mutually exclusive.\n";
}

$config_file = $opts{'c'} || $CONFIG_FILE;

# get selected hosts, validation comes after config parsing.
if ($opts{'h'}) {
    $host_option = 1;
    $host = $opts{'h'};
    if ($host =~ /,/) {
	@selected_hosts = split (/,\s*/, $host);
    }
    else {
	push (@selected_hosts, $host);
    }
}
else {
    $host_option = 0;
}

$debug_flag = $opts{'d'};

if ($#ARGV == -1) {
    die "Usage: distribute.pl [-4|-6|-p (prior year key)|-V (version)|-c config|-h hosts(CSV)|-k key|-d debug] [files]\n";
}

# Parse config file.
print "DEBUG: parsing config file $config_file\n" if ($debug_flag);
parse_config ($config_file);

# Override PKG_DIR if specified in config
if (defined($CONFIG{_GLOBAL}{PKG_DIR})) {
    $PKG_DIR = $CONFIG{_GLOBAL}{PKG_DIR};
    print "DEBUG: Using PKG_DIR from config: $PKG_DIR\n" if ($debug_flag);
}

# Select signing key for plain/custom files
if ($custom_key_option) {
    $signing_key_name = $custom_key_option;
    $signing_key_name .= '.sec' unless ($signing_key_name =~ /\.sec$/);
    $signing_sec_key = "$SIGNIFY_PUB_KEY_DIR/$signing_key_name";
    $signing_pub_key = $signing_sec_key;
    $signing_pub_key =~ s/\.sec$/.pub/;
    
    die "Custom signing key not found: $signing_sec_key\n" unless (-e $signing_sec_key);
    die "Custom public key not found: $signing_pub_key\n" unless (-e $signing_pub_key);
    
    ($signing_key_name) = basename($signing_sec_key) =~ /^(.*)\.sec$/;
    print "DEBUG: Using custom signing key: $signing_key_name\n" if ($debug_flag);
}
elsif ($use_prev_year_key) {
    # -p option: use prior year key
    $signing_sec_key = $PRIOR_SIGNIFY_SEC_KEY;
    $signing_pub_key = $PRIOR_SIGNIFY_PUB_KEY;
    $signing_key_name = $PRIOR_SIGNIFY_KEY_NAME;
    
    print "DEBUG: Using prior year signing key: $signing_key_name\n" if ($debug_flag);
}
elsif (defined($CONFIG{_GLOBAL}{DEFAULT_SIGNING_KEY})) {
    $signing_key_name = $CONFIG{_GLOBAL}{DEFAULT_SIGNING_KEY};
    $signing_key_name .= '.sec' unless ($signing_key_name =~ /\.sec$/);
    $signing_sec_key = "$SIGNIFY_PUB_KEY_DIR/$signing_key_name";
    $signing_pub_key = $signing_sec_key;
    $signing_pub_key =~ s/\.sec$/.pub/;
    ($signing_key_name) = basename($signing_sec_key) =~ /^(.*)\.sec$/;
    print "DEBUG: Using default signing key from config: $signing_key_name\n" if ($debug_flag);
}
else {
    # Default: use current year key based on domain
    $signing_sec_key = $SIGNIFY_SEC_KEY;
    $signing_pub_key = $SIGNIFY_PUB_KEY;
    $signing_key_name = $SIGNIFY_KEY_NAME;
    
    print "DEBUG: Using default signing key: $signing_key_name\n" if ($debug_flag);
}

# Validate selected signing key exists
if (!-e $signing_sec_key) {
    die "Signing key $signing_sec_key does not exist.\n";
}
if (!-e $signing_pub_key) {
    die "Public key $signing_pub_key does not exist.\n";
}

# Validate readability of signing key.
if (!-r $signing_sec_key) {
    die "Signing key $signing_sec_key is not readable.\n";
}

# Warn if signing key doesn't follow domain-year-pkg pattern
if ($signing_key_name !~ /^\Q$DOMAINNAME\E-\d+-pkg$/) {
    print "\n";
    print "Warning: Signing key '$signing_key_name' doesn't follow the standard pattern.\n";
    print "Expected pattern: $DOMAINNAME-YEAR-pkg (e.g., $DOMAINNAME-2026-pkg)\n";
    print "\n";
    print "Plain/custom files signed with this key will require explicit user\n";
    print "acceptance during installation on target systems.\n";
    print "\n";
    if (!yes_or_no("Continue with non-standard signing key? [y/n]: ")) {
        die "Aborted: non-standard signing key rejected.\n";
    }
    print "\n";
}

# Validate.
foreach $arg (@ARGV) {
    die "Unknown file. $arg\n" if (!defined ($CONFIG{$arg}));
    die "Error in config. Undefined TYPE \"$CONFIG{$arg}{TYPE}\".\n" if (!grep (/^$CONFIG{$arg}{TYPE}$/, @TYPES));
    push (@files, $arg);
    if ($CONFIG{$arg}{TYPE} eq 'custom') {
	push (@custom_pledges, @{$CUSTOM_PLEDGE{$arg}}) if ($CUSTOM_PLEDGE{$arg});
    }
}

# Validate @selected_hosts;
if ($opts{'h'}) {
    foreach $host (@selected_hosts) {
	die "-h $opts{'h'} specifies host not defined in config. $host\n" if (!grep(/^$host$/, @HOSTS));
    }
}

# Get the date (YYMMDD-HHMMSS).
$date = strftime ("%Y%m%d-%H%M%s", localtime (time()));
print "DEBUG: getting date: $date\n" if ($debug_flag);

# Warn about missing next year signing key if month is December.
if (!-e $SIGNIFY_PUB_KEY_NEXT && $date =~ /^..12/) {
    print "Warning: Next year's signing key and public key $SIGNIFY_PUB_KEY_NEXT do not exist.\n";
}

# Use pledge and unveil.
# Already got the date so don't need /usr/share/zoneinfo.
if ($^O eq 'openbsd') {
    my ($dir);
    
    # pledge. stdio already included.
    print "DEBUG: \@custom_pledges = @custom_pledges\n" if ($debug_flag);
    pledge ('rpath', 'wpath', 'cpath', 'exec', 'proc', 'fattr', 'unveil', @custom_pledges) || die "Cannot pledge promises. $!\n";

    # unveil, need read-only for all source locations, read-write-create
    # for destination locations, and read-execute for all commands used.
    # For plain files, get the dirname from path. For packages, they all
    # come from PKG_DIR. For custom -- special cased.
    foreach $file (@files) {
	if ($CONFIG{$file}{TYPE} eq 'plain') {
	    $dir = dirname ($CONFIG{$file}{FILE});
	    unveil ($dir, 'r');
	}
	elsif ($CONFIG{$file}{TYPE} eq 'custom') {
	    my $unveil_file;
	    if (defined ($CONFIG{$file}{UNVEIL})) {
		foreach $unveil_file (@{$CONFIG{$file}{UNVEIL}}) {
		    unveil ($unveil_file, 'r');
		}
	    }
	    if (defined ($CONFIG{$file}{UNVEILEXEC})) {
		foreach $unveil_file (@{$CONFIG{$file}{UNVEILEXEC}}) {
		    unveil ($unveil_file, 'rx');
		}
	    }
	}
    }
    unveil ($PKG_DIR, 'r');

    # unveil commands.
    # removed $MKTEMP.
    unveil ($MKDIR, 'rx');
    unveil ($RSYNC, 'rx');
    unveil ($SIGNIFY, 'rx');
    unveil ($STTY, 'rx');

    # Signify keys.
    unveil ($SIGNIFY_PUB_KEY_DIR, 'r');

    # For Signify gzip verification.
    unveil ('/dev/null', 'rwc');

    # Installation dir and temp dir.
    unveil ($INSTALL_DIR, 'rwc');
    unveil ('/tmp', 'rwc');

    # Required for Archive::Tar for some reason.
    unveil ('/', 'r');
    
    unveil ();
}

# Process.
# Create temp dir. We didn't used to need it for packages but we do now
# for signify signature verification due to error output going there.
if ($^O eq 'openbsd') {
    $temp_dir = mkdtemp ('/tmp/distribute.XXXXXXX');
}
else {
    $temp_dir = `$MKTEMP -d -q /tmp/distribute.XXXXXXX`;
    chomp ($temp_dir);
}

foreach $file (@files) {
    @process_hosts = ();
    print "DEBUG: processing file $file\n" if ($debug_flag);

    print "DEBUG: \@{\$CONFIG{\$file}{HOSTS}} = @{$CONFIG{$file}{HOSTS}}\n" if ($debug_flag);
    print "DEBUG: \@selected_hosts = @selected_hosts\n" if ($debug_flag && $host_option);

    # Put relevant hosts in @process_hosts.
    foreach $host (@{$CONFIG{$file}{HOSTS}}) {
	next if ($host_option && !grep (/^$host$/, @selected_hosts));
	push (@process_hosts, $host);
    }

    # Complain/die if -h selected no hosts.
    die "No selected hosts match for file $file. @selected_hosts\n" if ($host_option && @process_hosts == 0);
    
    # Accumulate syslock groups.
    foreach $host (@process_hosts){
	print "DEBUG: processing syslock groups for host $host\n" if ($debug_flag);
	(@{$syslock_groups{$host}}) = add_syslock_groups ($CONFIG{$file}{SYSLOCKGROUPS}, @{$syslock_groups{$host}});
    }

    if ($CONFIG{$file}{TYPE} eq 'package') {
	# Look for most up-to-date package in $PKG_DIR.
	$package_path = find_package ($PKG_DIR, $CONFIG{$file}{FILE});
	print "DEBUG: processing package $package_path\n" if ($debug_flag);
	# Verify signature.
	if (!verify_signature ($package_path, 1)) { # 1 = is_package
	    die "Invalid or missing signature. $package_path\n";
	}
	# Copy package to install directories.
	# We put these into host_package_path so they get shipped, but
	# not into host_package_files which get signed.
	@install_packages = copy_package ($package_path, @process_hosts);

	push (@files_to_ship_and_remove, @install_packages);
	# It's not dest_file or dest_dir in this case, it's just the
	# package filename, so we can add it to host_package_path so
	# that it gets shipped.
	($dest_file, $dest_dir) = fileparse ($package_path);
	foreach $host (@process_hosts) {
	    $host_package_path{$host} = "$INSTALL_DIR/$host/$dest_file";
	}
    }
    elsif ($CONFIG{$file}{TYPE} eq 'plain') {
	# Make sure file exists.
	die "File in config can't be found. $! $CONFIG{$file}{FILE}\n" if (!-e $CONFIG{$file}{FILE});
	print "DEBUG: processing plain file $file\n" if ($debug_flag);

	# If the destination is different from the source (DEST is used),
	# set up fake temp dir. (Need separate fake temp dir for each host
	# just in case some files are generated or otherwise different per
	# host.)
	if ($CONFIG{$file}{DEST}) {
	    $dest_path = $CONFIG{$file}{DEST};
	    ($dest_file, $dest_dir) = fileparse ($dest_path);
	    $dest_path = substr ($dest_path, 1, length ($dest_path) - 1);
	    foreach $host (@process_hosts) {
		# Make the fake directory (per-host).
		make_fake_dir ($temp_dir, $dest_dir, $host);
		# Copy the file into it. Preserve permissions.
		cp ($CONFIG{$file}{FILE}, "$temp_dir/$host/$dest_path");
	    }
	    $have_fake_dir = 1;
	}
	else {
	    $dest_path = $CONFIG{$file}{FILE};
	}
	# Add to file to package list.
	print "DEBUG: \@process_hosts = @process_hosts\n" if ($debug_flag);
	foreach $host (@process_hosts) {
	    print "DEBUG: adding $dest_path to package list for host $host\n" if ($debug_flag);
	    push (@{$host_package_files{$host}}, $dest_path);
	}
    }
    elsif ($CONFIG{$file}{TYPE} eq 'custom') {
	# Make sure file exists. (Ignore filenames with commas.)
	# With commas should probably split it out and check for all, but
	# will have to do $HOST substitution and check all relevant
	# instances.
	die "File in config can't be found. $! $CONFIG{$file}{FILE}\n" if (!-e $CONFIG{$file}{FILE} && $CONFIG{$file}{FILE} !~ /,/);
	print "DEBUG: processing custom file $file\n" if ($debug_flag);

	# Each is separate, for now. There may end up being some different
	# custom types that have common features.
	if ($file eq 'doas.conf') {
	    _custom_doas_dot_conf ($temp_dir, $CONFIG{$file}{CUSTOMVARS}, $CONFIG{$file}{DEST}, @process_hosts);
	    $have_fake_dir = 1;
	}
	# Change old IP address to new IP address in a list of files for
	# distribution to fnord and nkrumah (see config).
	# Dest dirs are pulled from config:
	# /etc, /etc/mail, /home/_rsyncu/.ssh
	# This does not change /etc/faild.conf for hagbard.
	elsif ($file eq 'ip-address') {
	    _custom_ip_address ($temp_dir, $CONFIG{$file}{CUSTOMVARS}, $CONFIG{$file}{FILE}, $CONFIG{$file}{DEST}, @process_hosts);
	    $have_fake_dir = 1;
	}
	else {
	    die "Error in config. Don't know how to handle custom type for \"$file\".\n";
	}
    }
    else {
	die "Shouldn't happen. Error in config. Undefined TYPE \"$CONFIG{$file}{TYPE}\".\n";
    }
}

# %host_package_files are packages we created that need to be signed.
if (%host_package_files) {
    $signify_passphrase = get_signify_passphrase();
}

# If there were any plain or custom files, create and sign the gzips, then copy
# the packages to the install directory.
foreach $host (keys (%host_package_files)) {
    print "DEBUG: creating package for plain and custom for host $host\n" if ($debug_flag);
    $host_package_path{$host} = create_package ($have_fake_dir, $temp_dir, $date, $host, @{$host_package_files{$host}});
    if (!Signify::sign_gzip ($host_package_path{$host}, $signify_passphrase, $signing_sec_key, $temp_dir)) {
	my @errors = Signify::signify_error();
	die "Could not sign package with $signing_key_name: @errors\n";
    }

    push (@files_to_ship_and_remove, copy_package ($host_package_path{$host}, $host));

    # Create syslock group file if any syslock groups are specified.
    if (@{$syslock_groups{$host}}) {
	print "DEBUG: creating syslock group file for $host\n" if ($debug_flag);
	print "DEBUG: \@{\$syslock_groups{\$host}} = @{$syslock_groups{$host}}\n" if ($debug_flag);
	create_syslock_group_file ("$host_package_path{$host}.grp", @{$syslock_groups{$host}});
	# Sign it.
	if (!Signify::sign ("$host_package_path{$host}.grp", $signify_passphrase, $signing_sec_key)) {
	    @errors = Signify::signify_error();
	    die "Could not sign syslock group file $host_package_path{$host}.grp with $signing_key_name: @errors\n";
	}   
	# Add both syslock group file and signature to @files_to_ship_and_remove.
	push (@files_to_ship_and_remove, copy_package ("$host_package_path{$host}.grp", $host));
	push (@files_to_ship_and_remove, copy_package ("$host_package_path{$host}.grp.sig", $host));
    }
}

# Now actually distribute the packages to the destinations.
# Instead of doing one at a time we could ship all at once, which
# might be a lot nicer. Would need to find all the matches and add
# them to the command line list, then use the same list to unlink
# them.
foreach $host (keys (%host_package_path)) {
    @rsync_file_list = ();
    foreach $package_path (@files_to_ship_and_remove) {
	if ($package_path =~ /^\/var\/install\/$host\//) {
	    push (@rsync_file_list, $package_path);
	    # With rsync_wrapper.sh	    
	    # system ("$RSYNC --rsync-path=/usr/local/sbin/rsync_wrapper.sh -avr $package_path $host-rsnapshot:/var/install/");
	    # With rrsync: the authorized_keys file forces rrsync -doas /var/install.
	}	    
    }
    print "Distributing to $host.\n";
    system ($RSYNC, '-avr', @rsync_file_list, "$host$rsync_host_suffix:.");
}

# Now clean it all up and delete them.
foreach $file (@files_to_ship_and_remove) {
    unlink ($file);
}

# Exit temp subdir, but stay in /tmp.
chdir ('/tmp');

# Remove the fake dirs if we're done with them. (Superfluous.)
#if ($have_fake_dir) {
#    rmtree ("$temp_dir/$file");
#}

# Delete temp dir.
rmtree ($temp_dir);

### Subroutines.

# Subroutine to parse config file.
sub parse_config {
    my ($config_file) = @_;

    my ($context);
    my $GLOBAL_CONTEXT = 1;
    my $FILE_CONTEXT = 2;
    
    my ($line_no, @host_list, @syslock_groups_list,
	$field, $value, $current_name,
	@syslock_groups, $group, @hosts, $host, @except_hosts);
    my ($got_file, $got_dest, $got_type, $got_syslock_groups, $got_hosts);
    my (%macros, $macro_name, $have_macros, $more_to_process);

    $line_no = 0;
    $context = $GLOBAL_CONTEXT;

    open (FILE, '<', $config_file) || die "Cannot open config file $config_file. $!\n";
    while (<FILE>) {
	chomp;
	$line_no++;
	if (/^\s*#|^\s*$/) {
	    # ignore
	}
	# Macro definition. Can occur anywhere so long as definition is before use.
	elsif (/^([\w\-]+)\s*=\s*\"([\S ]+)\"$/) {
	    $field = $1;
	    $value = $2;
	    die "Macro \"$field\" defined a second time on line $line_no. $_\n" if (defined ($macros{$field}));
	    $macros{$field} = $value;
	    $have_macros = 1;
	}
	elsif (/\s*([\w\-]+):\s*(.*)$/) {
	    $field = $1;
	    $value = $2;

	    # any macros to expand?
	    $more_to_process = 1;
	    while ($have_macros && $more_to_process) {
		if ($value =~ /%%([\w\-]+)%%/) {
		    $macro_name = $1;
		    if (defined ($macros{$macro_name})) {
			$value =~ s/%%$macro_name%%/$macros{$macro_name}/g;
		    }
		    else {
			die "Undefined macro %%$macro_name%% on line $line_no. $_\n";
		    }
		}
		else {
		    $more_to_process = 0;
		}
	    }
	    
	    if ($field eq 'host-list') {
		die "A \"host-list:\" field in file context on line $line_no. $_\n" if ($context == $FILE_CONTEXT);
		die "A second \"host-list:\" field on line $line_no. $_\n" if (@host_list);
		@host_list = split (/,\s*/, $value);
		push (@HOSTS, @host_list); # global like %CONFIG
	    }
	    elsif ($field eq 'syslock-groups-list') {
		die "A \"syslock-groups-list:\" field in file context on lin $line_no. $_\n" if ($context == $FILE_CONTEXT);
		die "A second \"syslock-groups-list:\" field on line $line_no. $_\n" if (@syslock_groups_list);
		@syslock_groups_list = split (/,\s*/, $value);
	    }
	    elsif ($field eq 'default-signing-key') {
		die "A \"default-signing-key:\" field in file context on line $line_no. $_\n" if ($context == $FILE_CONTEXT);
		die "A second \"default-signing-key:\" field on line $line_no. $_\n" if (defined($CONFIG{_GLOBAL}{DEFAULT_SIGNING_KEY}));
		
		# Expand variables
		$value =~ s/\$DOMAINNAME/$DOMAINNAME/g;
		$value =~ s/\$YEAR/$year/g;

		# Check for standard format.
		if ($value !~ /^[\w\.\-]+-\d+-pkg$/) {
		    print "Warning: default-signing-key '$value' doesn't follow standard pattern (domain-year-pkg)\n";
		    print "This key will require user prompting during installation.\n";
		}
		
		$CONFIG{_GLOBAL}{DEFAULT_SIGNING_KEY} = $value;
	    }
	    elsif ($field eq 'pkg-dir') {
		die "A \"pkg-dir:\" field in file context on line $line_no. $_\n" if ($context == $FILE_CONTEXT);
		die "A second \"pkg-dir:\" field on line $line_no. $_\n" if (defined($CONFIG{_GLOBAL}{PKG_DIR}));
		
		$CONFIG{_GLOBAL}{PKG_DIR} = $value;
	    }
	    elsif ($field eq 'name') {
		if ($context == $GLOBAL_CONTEXT) {
		    die "No \"host-list:\" defined before first \"name:\" field on line $line_no. $_\n" unless (@host_list);
		    $context = $FILE_CONTEXT;
		}
		if (defined ($current_name)) {
		    # Did we get required fields for previous? Also need to check this at end of file for the last one.
		    die "No \"file:\" defined for \"name: $current_name\" before next \"name:\" on line $line_no. $_\n" if (!$got_file);
		    die "No \"type:\" defined for \"name: $current_name\" before next \"name:\" on line $line_no. $_\n" if (!$got_type);
		    # syslock-groups should always be optional.
#		    die "No \"syslock-groups:\" defined for \"name: $current_name\" before next \"name:\" on line $line_no. $_\n" if (!$got_syslock_groups && $CONFIG{$current_name}{TYPE} ne 'package' && @syslock_groups_list); # optional for packages, or for everything if no syslock-groups-list defined.
		    die "No \"hosts:\" defined for \"name: $current_name\" before next \"name:\" on line $line_no. $_\n" if (!$got_hosts);
		    $got_file = 0;
		    $got_dest = 0;
		    $got_type = 0;
		    $got_syslock_groups = 0;
		    $got_hosts = 0;
		}
		$current_name = $value;
		die "A second \"name:\" using $value on line $line_no. $_\n" if (defined ($CONFIG{$current_name}{FILE}));
		$CONFIG{$current_name}{FILE} = '';
	    }
	    elsif ($field eq 'file') {
		die "A \"file:\" field in global context on line $line_no. $_\n" if ($context == $GLOBAL_CONTEXT);
		die "A second \"file:\" for $current_name on line $line_no. $_\n" if ($got_file);
		if ($current_name eq "$DOMAINNAME-pkg.pub-current") {
		    $value = $SIGNIFY_PUB_KEY if ($value eq '$SIGNIFY_PUB_KEY');
		}
		elsif ($current_name eq "$DOMAINNAME-pkg.pub-next") {
		    $value = $SIGNIFY_PUB_KEY_NEXT if ($value eq '$SIGNIFY_PUB_KEY_NEXT');
		}
		$CONFIG{$current_name}{FILE} = $value;
		$got_file = 1;
	    }
	    elsif ($field eq 'dest') {
		die "A \"dest:\" field in global context on line $line_no. $_\n" if ($context == $GLOBAL_CONTEXT);
		die "A second \"dest:\" for $current_name on line $line_no. $_\n" if ($got_dest);
		if ($current_name eq "$DOMAINNAME-pkg.pub-current") {
		    $value = $SIGNIFY_PUB_KEY if ($value eq '$SIGNIFY_PUB_KEY');
		}
		elsif ($current_name eq "$DOMAINNAME-pkg.pub-next") {
		    $value = $SIGNIFY_PUB_KEY_NEXT if ($value eq '$SIGNIFY_PUB_KEY_NEXT');
		}
		$CONFIG{$current_name}{DEST} = $value;
		$got_dest = 1; # optional; forbidden for package type
		if ($got_type && $CONFIG{$current_name}{TYPE} eq 'package') {
		    die "A \"dest:\" field is not permitted for \"package\" type file \"$current_name\" on line $line_no. $_\n";
		}
	    }
	    elsif ($field eq 'type') {
		die "A \"type:\" field in global context on line $line_no. $_\n" if ($context == $GLOBAL_CONTEXT);
		die "A second \"type:\" for $current_name on line $line_no. $_\n" if ($got_type);
		die "Invalid type \"$value\" on line $line_no. $_\n" if (!grep (/^$value$/, @TYPES));
		$CONFIG{$current_name}{TYPE} = $value;
		$got_type = 1;
		if ($got_dest && $CONFIG{$current_name}{TYPE} eq 'package') {
		    die "A \"dest:\" field is not permitted for \"package\" type file \"$current_name\" on line $line_no. $_\n";
		}
	    }
	    elsif ($field eq 'syslock-groups') {
		die "A \"syslock-groups:\" field in global context on line $line_no. $_\n" if ($context == $GLOBAL_CONTEXT);
		die "A \"syslock-groups:\" field used with no \"syslock-groups-list:\" defined on line $line_no. $_\n" unless (@syslock_groups_list);
		die "A second \"syslock-groups:\" for $current_name on line $line_no. $_\n" if ($got_syslock_groups);
		@syslock_groups = split (/,\s*/, $value);
		foreach $group (@syslock_groups) {
		    next if grep (/^$group$/, @syslock_groups_list);
		    die "Unknown syslock group \"$group\" in \"syslock-groups:\" field on line $line_no. $_\n";
		}
		push (@{$CONFIG{$current_name}{SYSLOCKGROUPS}}, @syslock_groups);
		$got_syslock_groups = 1;
	    }
	    elsif ($field eq 'unveil') {
		die "An \"unveil:\" field in global context on line $line_no. $_\n" if ($context == $GLOBAL_CONTEXT);
		# for custom only
		die "An \"unveil:\" found for non-custom $current_name on line $line_no. $_\n" if ($CONFIG{$current_name}{TYPE} ne 'custom');
		die "A second \"unveil:\" for $current_name on line $line_no. $_\n" if (defined ($CONFIG{$current_name}{UNVEIL}));
		push (@{$CONFIG{$current_name}{UNVEIL}}, split (/,\s*/, $value));
	    }
	    elsif ($field eq 'unveil-exec') {
		die "An \"unveil-exec:\" field in global context on line $line_no. $_\n" if ($context == $GLOBAL_CONTEXT);
		# for custom only
		die "An \"unveil-exec:\" found for non-custom $current_name on line $line_no. $_\n" if ($CONFIG{$current_name}{TYPE} ne 'custom');
		die "A second \"unveil-exec:\" for $current_name on line $line_no. $_\n" if (defined ($CONFIG{$current_name}{UNVEILEXEC}));
		push (@{$CONFIG{$current_name}{UNVEILEXEC}}, split (/,\s*/, $value));
	    }
	    elsif ($field eq 'custom-vars') {
		die "A \"custom-vars:\" field in global context on line $line_no. $_\n" if ($context == $GLOBAL_CONTEXT);
		# for custom only
		die "An \"custom-vars:\" found for non-custom $current_name on line $line_no. $_\n" if ($CONFIG{$current_name}{TYPE} ne 'custom');
		die "A second \"custom-vars:\" for $current_name on line $line_no. $_\n" if (defined ($CONFIG{$current_name}{CUSTOMVARS}));
		my @custom_vars = split (/,\s*/, $value);
		my $custom_var;
		foreach $custom_var (@custom_vars) {
		    if ($custom_var =~ /\s*([\w\-]+)\s*=\s*([\S ]+)$/) {
			${$CONFIG{$current_name}{CUSTOMVARS}}{$1} = $2;
		    }
		    else {
			die "Invalid format in \"custom-vars:\" \"$custom_var\" on line $line_no. $_\n";
		    }
		}
	    }
	    elsif ($field eq 'hosts') {
		die "A \"hosts:\" field in global context on line $line_no. $_\n" if ($context == $GLOBAL_CONTEXT);
		die "A \"hosts:\" field used with no \"host-list:\" defined on line $line_no. $_\n" unless (@host_list);
		die "A second \"hosts:\" for $current_name on line $line_no. $_\n" if ($got_hosts);
		if ($value eq 'all') {
		    @hosts = @host_list;
		}
		elsif ($value =~ /^all except (.*)$/) {
		    $value = $1;
		    @except_hosts = split (/,\s*/, $value);
		    foreach $host (@except_hosts) {
			next if grep (/^$host$/, @host_list);
			die "Unknown host \"$host\" in \"hosts:\" field on line $line_no. $_\n";
		    }
		    @hosts = (); # empty array
		    foreach $host (@host_list) {
			next if grep (/^$host$/, @except_hosts);
			push (@hosts, $host);
		    }
		}
		else { # just a list of hosts
		    @hosts = split (/,\s*/, $value);
		    foreach $host (@hosts) {
			next if grep (/^$host$/, @host_list);
			die "Unknown host \"$host\" in \"hosts:\" field on line $line_no. $_\n";
		    }
		}
		push (@{$CONFIG{$current_name}{HOSTS}}, @hosts);
		$got_hosts = 1;
	    }
	    else {
		die "Invalid config field name \"$field\" on line $line_no. $_\n";
	    }
	}
	else {
	    die "Unknown config line on line $line_no. $_\n";
	}
    }
    close (FILE);

    # Did we get required fields for last "name:"? Same checks as at each subsequent "name:" above.
    die "No \"file:\" defined for \"name:\" $current_name before next \"name:\" on line $line_no. $_\n" if (!$got_file);
    die "No \"type:\" defined for \"name:\" $current_name before next \"name:\" on line $line_no. $_\n" if (!$got_type);
    # syslock-groups should always be optional.
#    die "No \"syslock-groups:\" defined for \"name:\" $current_name before next \"name:\" on line $line_no. $_\n" if (!$got_syslock_groups);
    die "No \"hosts:\" defined for \"name:\" $current_name before next \"name:\" on line $line_no. $_\n" if (!$got_hosts);
}

# Subroutine to find a package.
sub find_package {
    my ($pkg_dir, $pkg_start) = @_;
    my (@files, $file, $version, $check_version, $pkg_path);

    if ($pkg_start =~ /^(.*)-PKG$/) {
	$pkg_start = $1;
    }
    else {
	die "Error in config. Package filename doesn't end in \"-PKG\". $pkg_start\n";
    }

    opendir (DIR, $pkg_dir) || die "Could not open directory $pkg_dir. $!\n";
    @files = grep (!/^\.{1,2}$/, readdir (DIR));
    closedir (DIR);

    foreach $file (@files) {
	if ($file =~ /^$pkg_start-([\w\.]+)\.tgz$/ || $file =~ /^$pkg_start-([\w\.]+-no_[\w]+)\.tgz$/) {
	    # This currently matches python-tkinter-xxx and not just
	    # python-xxx. Is it safe to restrict $1 to numbers, letters,
	    # and periods, and exclude hyphens? i.e., ([\w\.]+)
	    # instead of (.*)?
	    $check_version = $1;
	    
	    if (!defined ($version)) {
		$version = $check_version;
	    }
	    elsif (version_gt ($check_version, $version)) {
		$version = $check_version;
	    }
	}
    }
    die "Could not find $pkg_start package in $PKG_DIR.\n" if (!$version);
    $pkg_path = $PKG_DIR . '/' . $pkg_start . '-' . $version . '.tgz';
    return ($pkg_path);
}

# Returns 1 if $version1 > $version2.
sub version_gt {
    my ($version1, $version2) = @_;
    
    my ($v1_major, $v1_minor, $v1_patch, $v1_portrevision, $v1_vv) = version_parse ($version1);
    my ($v2_major, $v2_minor, $v2_patch, $v2_portrevision, $v2_vv) = version_parse ($version2);

    return 1 if ($v1_major > $v2_major);
    return 0 if ($v1_major < $v2_major);
    return 1 if ($v1_minor > $v2_minor);
    return 0 if ($v1_minor < $v2_minor);
    return 1 if ($v1_patch > $v2_patch);
    return 0 if ($v1_patch < $v2_patch);
    return 1 if ($v1_vv gt $v2_vv);
    return 0 if ($v1_vv lt $v2_vv);
    return 1 if ($v1_portrevision gt $v2_portrevision);
    return 0;
}

# Parses versions.
# maj.min.pat(pN)(vN) (Many OpenBSD ports: 3.11.10p0, 9.20.8p0v3, 9.20.9v3)
# maj.min(alpha)(pN) (reportnew, py3-packaging)
# yyyy[.]mmdd(alpha)(pN)(vN) (rsync-tools, p5-Time-modules)
# maj.min.yyyymmdd(pN)(vN) (wireguard-tools)
# Doesn't support perl's vMAJOR.MINOR.PATcH
sub version_parse {
    my ($version) = @_;
    my ($major, $minor, $patch, $portrevision, $v_epoch);

    $portrevision = -1; # if not found

    # maj.min.pat(pN)(vN)
    if ($version =~ /^(\d+)\.(\d+)\.(\d+)(p\d+)*(v\d+)*$/) {
	$major = $1;
	$minor = $2;
	$patch = $3;
	$portrevision = $4 if (defined ($4));
	$v_epoch = $5 if (defined ($5));
    }
    # maj.min(alpha)(pN) (reportnew, py3-packaging)
    elsif ($version =~ /^(\d+)\.(\d+)([a-o])*(p\d+)*$/) {
	$major = $1;
	$minor = $2;
	$v_epoch = $3 if (defined ($3));
	$portrevision = $4 if (defined ($4));
    }
    # yyyy[.]mmdd(alpha)(pN)(vN) (rsync-tools, p5-Time-modules)
    elsif ($version =~ /^(\d{4})\.*(\d{2})(\d{2})([a-o]*)(p\d+)*(v\d+)*$/) {
	$major = $1;
	$minor = $2;
	$patch = $3;
	$v_epoch = $4 if (defined ($4)); # alpha
	$portrevision = $5 if (defined ($5));
	# alpha & vN - if really need both, should break out alpha?
	if (defined ($6) && defined ($v_epoch)) {
	    die "Cannot parse version \"$version\". Match on both an alpha patch and vN.\n";
	}
	# vN
	$v_epoch = $6 if (defined ($6));
    }
    # maj.min.yyyymmdd(pN)(vN) (wireguard-tools)
    elsif ($version =~ /^(\d+)\.(\d+)\.(\d{8})(p\d+)*(v\d+)*$/) {
	$major = $1;
	$minor = $2;
	$patch = $3;
	$portrevision = $4 if (defined ($4));
	$v_epoch = $5 if (defined ($5));
    }
    else {
	die "Cannot parse version \"$version\".\n";
    }

    return ($major, $minor, $patch, $portrevision, $v_epoch);
}

# Subroutine to get signify passphrase.
sub get_signify_passphrase {
    my ($signify_passphrase);
    
    # Get signify passphrase.
    system ($STTY, '-echo');
    print "signify passphrase: ";
    $signify_passphrase = <STDIN>;
    system ($STTY, 'echo');
    chomp ($signify_passphrase);
    return ($signify_passphrase);
}

# Subroutine to copy package to appropriate install dirs.
sub copy_package {
    my ($pkg_path, @hosts) = @_;
    my ($host, $file_basename, @ship_files);

    foreach $host (@hosts) {
	copy ($pkg_path, "$INSTALL_DIR/$host/");
	$file_basename = basename($pkg_path);
	push (@ship_files, "$INSTALL_DIR/$host/$file_basename");
    }
    
    return (@ship_files);
}

# Subroutine to create package tar file for a host. This has to be done
# all at once for a gzipped tar file -- the "r" command won't work.
sub create_package {
    my ($have_fake_dir, $temp_dir, $date, $host, @file_list) = @_;
    my ($pkg_path, $file, $file_wo_slash);

    if ($have_fake_dir) {
	chdir ("$temp_dir/$host");
    }

    $pkg_path = "$temp_dir/$host-$date-package.tgz";

    if (-e $pkg_path) {
	die "Error, $pkg_path already exists.\n";
    }

    # Using the perl module is better than calling system on the command and piping
    # STDERR to /dev/null to avoid the error message about stripping the initial /.
    # The module won't extract with a leading slash so we need to remove them.
    my $tar = Archive::Tar->new;
    $tar->add_files (@file_list);
    foreach $file (@file_list) {
	$file_wo_slash = $file;
	$file_wo_slash =~ s/^\///;
	if (!$tar->rename ($file, $file_wo_slash)) {
	    print "Unable to rename $file to $file_wo_slash in tar file.\n";
	}
    }
    $tar->write ($pkg_path, COMPRESS_GZIP);

    return ($pkg_path);
}

# Subroutine to make fake dir for addition of plain files that have
# destinations different from source location. Has to be per-host
# just in case some config files are different per host.
# Returns if the directory already exists.
sub make_fake_dir {
    my ($temp_dir, $dest_dir, $host) = @_;

    return if (-d "$temp_dir/$host$dest_dir");
    system ($MKDIR, '-p', "$temp_dir/$host$dest_dir");
}

### Custom packages.

# Subroutine to validate custom variables.
sub _custom_validate_custom_vars {
    my ($file, $custom_vars, %req_opt_custom_vars) = @_;
    my (%custom_vars, $custom_var);

    %custom_vars = %{$custom_vars};

    foreach $custom_var (keys (%req_opt_custom_vars)) {
	die "Config is missing required custom variable \"$custom_var\" for $file.\n" if (!defined ($custom_vars{$custom_var}) && $req_opt_custom_vars{$custom_var} eq 'required');
    }

    # Make sure all variables are either required or optional.
    foreach $custom_var (keys (%custom_vars)) {
	die "Config specifies undefined custom variable \"$custom_var\" for $file.\n" if (!grep (/^$custom_var$/, keys (%req_opt_custom_vars)))
    }
}

# Subroutine for custom doas.conf generation and distribution.
sub _custom_doas_dot_conf {
    my ($temp_dir, $custom_vars, $dest_path, @hosts) = @_;
    my (%custom_vars, $dest_file, $dest_dir, $host);
    # global: $have_fake_dir, %host_package_files

    my %REQ_OPT_CUSTOM_VARS = ('gendoas' => 'required');

    _custom_validate_custom_vars ('doas.conf', $custom_vars, %REQ_OPT_CUSTOM_VARS);

    %custom_vars = %{$custom_vars};

    # required custom vars: gendoas=/path/to/gendoas

    my $PERL = '/usr/bin/perl';
    my $GENDOAS = $custom_vars{'gendoas'};

    die "$! $GENDOAS\n" if (!-e $GENDOAS);

    ($dest_file, $dest_dir) = fileparse ($dest_path);
    $dest_path = substr ($dest_path, 1, length ($dest_path) - 1);
#    $have_fake_dir = 1; # done after call to this subroutine
    foreach $host (@hosts) {
	make_fake_dir ($temp_dir, $dest_dir, $host);
	chdir ("$temp_dir/$host$dest_dir");
	system ($PERL, $GENDOAS, $host);
	push (@{$host_package_files{$host}}, $dest_path);
    }
}

# Subroutine for custom IP address change.
sub _custom_ip_address {
    my ($temp_dir, $custom_vars, $file, $dest, @hosts) = @_;
    my (%custom_vars, $old_address, $new_address,
	@source_paths, @dest_paths,
	$host, $idx, $source_path, $dest_path);
    # global: $have_fake_dir, %host_package_files
    
    my %REQ_OPT_CUSTOM_VARS = ('wan0' => 'required',
			       'wan1' => 'optional',
			       'wan0-host-fqdn' => 'optional',
			       'wan1-host-fqdn' => 'optional',
			       'ipv6-name' => 'required',
			       'dns' => 'required');

    _custom_validate_custom_vars ('ip-address', $custom_vars, %REQ_OPT_CUSTOM_VARS);
    
    %custom_vars = %{$custom_vars};

    my $CHMOD = '/bin/chmod';
    
    ($old_address, $new_address) = _custom_get_old_and_new_ip_addresses ($custom_vars{'wan0-host-fqdn'}, $custom_vars{'wan1-host-fqdn'}, $custom_vars{'ipv6-name'}, $custom_vars{'dns'}, $custom_vars{'wan0'}, $custom_vars{'wan1'});;
    @source_paths = split (/,/, $file);
    @dest_paths = split (/,/, $dest);
#	    $have_fake_dir = 1; done after call to this subroutine
    # I really want to take each corresponding source and dest path
    # to work on for each host as appropriate, so I need to use a
    # for loop instead of foreach.
    foreach $host (@hosts) {
	for ($idx = 0; $idx <= $#source_paths; $idx++) {
	    $source_path = $source_paths[$idx];
	    $dest_path = $dest_paths[$idx];
	    ($dest_file, $dest_dir) = fileparse ($dest_path);
	    $dest_path = substr ($dest_path, 1, length ($dest_path) - 1);
	    # Need to insert $host in middle of source path.
	    # $HOST is special-cased just like $SIGNIFY_PUB_KEY and
	    # $SIGNIFY_PUB_KEY_NEXT (except the latter two are done
	    # at config parse time rather than execution time).
	    if ($source_path =~ /\$HOST/) {
		$source_path =~ s/\$HOST/$host/;
		# Check for source path existence. (Is backup mounted?)
		# Would be better if this were more graceful, cleaned
		# up temp files, or even alternatively used another
		# source (/var/db/servers is available).
		if (!-e $source_path) {
		    die "Source path missing, can use /var/db/servers if urgent: $source_path\n";
		}

		# It doesn't hurt to do this if the dir already exists.
		make_fake_dir ($temp_dir, $dest_dir, $host);
		# Copy the source file to the destination. -p to
		# preserve permissions. (Doesn't work for pf.conf.)
		cp ($source_path, "$temp_dir/$host/$dest_path");

		# Update the file by changing the IP addresses.
		_custom_global_replace_in_file ("$temp_dir/$host/$dest_path", $old_address, $new_address);

		# Manually remove g and o read permissions.
		# This must occur AFTER the call to _custom_global_replace_in_file,
		# which creates a new file with default permissions.
		if ($dest_path =~ /\/pf\.conf$/) {
		    system ($CHMOD, 'go-r', "$temp_dir/$host/$dest_path");
		}
		
		push (@{$host_package_files{$host}}, $dest_path);
	    }
	}
    }
}

# Subroutine to get old external IP address from DNS and new
# external IP address via prompt.
# Assumes IPv6 is tunnel over wan0.
sub _custom_get_old_and_new_ip_addresses {
    my ($wan0_host_fqdn, $wan1_host_fqdn, $ipv6_name, $dns, $wan0, $wan1) = @_;
    use Socket qw( :addrinfo SOCK_RAW );
    my ($old_address, $new_address, $wan0_or_wan1,
	$lc_wan0, $lc_wan1, $host_fqdn);
    my ($err);

    $lc_wan0 = lc ($wan0);

    if (!defined ($wan1)) {
	$wan0_or_wan1 = $wan0;
    }
    else {
	$wan0_or_wan1 = 'null';
	$lc_wan1 = lc ($wan1);
    }

    while ($wan0_or_wan1 eq 'null') {
	print "$wan0 or $wan1? ";
	$wan0_or_wan1 = <STDIN>;
	chomp ($wan0_or_wan1);
	$wan0_or_wan1 =~ tr/A-Z/a-z/;
	$wan0_or_wan1 = 'null' unless ($wan0_or_wan1 eq $lc_wan0 || $wan0_or_wan1 eq $lc_wan1);
    }

    print "Warning: Must manually update /etc/faild.conf and /etc/reportnew/reportnew.conf.\n";
    if ($wan0_or_wan1 eq $lc_wan0) {
	# Assume wan0 has IPv6 tunnel.
	print "Distributing via v4 (default) since v6 tunnel is down.\n";
	print "Warning: Must manually update $ipv6_name tunnel.\n";
	print "Warning: Must manually update firewall tunnel and policies.\n";
	$rsync_host_suffix = $RSYNC_HOST_SUFFIXv4;
	$host_fqdn = $wan0_host_fqdn;
    }
    else { # wan1
	print "Distributing via v6 since v4 address doesn't have access.\n";
	print "Warning: Must manually update DNS record via $dns.\n";
	$rsync_host_suffix = $RSYNC_HOST_SUFFIXv6;
	$host_fqdn = $wan1_host_fqdn;
    }
    if (defined ($host_fqdn)) {
	$old_address = _get_wan_ip ($host_fqdn);
    }
    else {
	$old_address = 'null';
    }
    while (1) {
	print "Old address: $old_address (return or enter correct): ";
	my $input_string = <STDIN>;
	chomp ($input_string);
	if ($input_string =~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/) {
	    $old_address = $input_string;
	    last;
	}
	elsif ($input_string eq '') {
	    $input_string = $old_address;
	    last;
	}
	else {
	    print "Invalid response \"$input_string\". Enter new IP or hit return.\n";
	}
    }
    
    $new_address = 'null';
    while ($new_address eq 'null') {
    	  print "New IP Address: ";
    	  $new_address = <STDIN>;
    	  chomp ($new_address);
	  $new_address = 'null' if ($new_address !~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);
    }
    
    return ($old_address, $new_address);
}

# Subroutine to get WAN IP from fqdn.
sub _get_wan_ip {
    my ($host_fqdn) = @_;
    my ($old_address, $err, @res, $ai);

    ($err, @res) = getaddrinfo ($host_fqdn, "", {socktype => SOCK_RAW});
    if ($err) {
	print "Cannot getaddrinfo - $err";
	$old_address = 'null';
	return ($old_address);
    }
    while ( $ai = shift @res ) {
	($err, $old_address) = getnameinfo($ai->{addr}, NI_NUMERICHOST, NIx_NOSERV);
	if ($err) {
	    print "Cannot getnameinfo - $err";
	    $old_address = 'null';
	    return ($old_address);
	}
    }
    return ($old_address);
}

# Subroutine to do global string replacement on a given file.
sub _custom_global_replace_in_file {
    my ($file, $string, $replace) = @_;
    my $backup_file;

    $backup_file = $file . '.bak';

    rename ($file, $backup_file);
    open (INFILE, '<' . $backup_file) or die "Cannot open file. $backup_file $!\n";
    open (OUTFILE, '>' . $file) || die "Cannot open file for writing. $file $!\n";
    while (<INFILE>) {
	s/$string/$replace/g;
	print OUTFILE $_;
    }
    close (INFILE);
    close (OUTFILE);
    unlink ($backup_file);
}

### End custom packages.

# Subroutine to add any new syslock groups from config file entries.
sub add_syslock_groups {
    my ($config_syslock_groups, @syslock_groups) = @_;
    my ($syslock_group);

    foreach $syslock_group (@{$config_syslock_groups}) {
	push (@syslock_groups, $syslock_group) unless (grep (/^$syslock_group$/, @syslock_groups));
    }
    
    return (@syslock_groups);
}

# Subroutine to create syslock group file.
sub create_syslock_group_file {
    my ($file, @syslock_groups) = @_;
    my $syslock_group;

    open (FILE, '>', $file) || die "Cannot open $file for writing. $!\n";
    foreach $syslock_group (@syslock_groups) {
	print FILE "$syslock_group\n";
    }
    close (FILE);
}

### Following subroutines are present in both distribute.pl and install.pl
### and should be kept consistent.

## This subroutine is borrowed from sigtree.pl.
# Ask a yes or no question.
sub yes_or_no {
    my ($query) = @_;
    my ($answer);

    while (1) {
        print "$query";
        $answer = <STDIN>;
        chomp ($answer);

        if ($answer eq 'yes' || $answer eq 'y') {
            return 1;
        }
        elsif ($answer eq 'no' || $answer eq 'n') {
            return 0;
        }
        else {
            print "Please answer \"yes\" or \"no\".\n";
        }
    }
}

# Subroutine used in both distribute.pl and install.pl, be sure to keep
# consistent.
# Now uses Signify.pm to do most of the work.
sub verify_signature {
    my ($gzip_path, $is_package) = @_;
    my ($signer, $signdate, @errors);
    my ($public_key, $signer_key_file, $signer_key_dir);
    my ($key_type, $num);
    
    print "DEBUG: Verifying " . ($is_package ? "package" : "plain/custom") . ": $gzip_path\n" if ($debug_flag);

    ($signer, $signdate) = Signify::verify_gzip ($gzip_path, $temp_dir,
						 "$SIGNIFY_KEY_NAME.pub",
						 $SIGNIFY_SEC_KEY);
    @errors = Signify::signify_error;
    
    if (!@errors) {
	print "DEBUG: Verified with expected key: $SIGNIFY_KEY_NAME.sec\n" if ($debug_flag);
	return 1;
    }
    
    elsif ($errors[0] =~ /public key is \"(.*)\" but/) {
	$public_key = $1;
	($signer, $signdate) = Signify::verify_gzip ($gzip_path, $temp_dir);
	@errors = Signify::signify_error;
	
	if (@errors) {
	    print "@errors";
	    return 0;
	}
	
	($signer_key_file, $signer_key_dir) = fileparse ($signer);
	if ($signer_key_dir ne $SIGNIFY_PUB_KEY_DIR && $signer_key_dir ne './') {
	    print "Not signed by a key in $SIGNIFY_PUB_KEY_DIR, signed by $signer.\n";
	    return 0;
	}
	
	if ($is_package) {
	    if ($signer_key_file =~ /^([\w\.\-]+)-(\d+)-pkg\.sec$/) {
		$key_type = $1;
		$num = $2;
		if ($num >= $SIGNIFY_MIN_YEAR) {
		    print "DEBUG: Package signed with valid key: $signer_key_file\n" if ($debug_flag);
		    return 1;
		}
		else {
		    print "Package key $signer_key_file does not meet minimum year $SIGNIFY_MIN_YEAR.\n";
		    return 0;
		}
	    }
	    elsif ($^O eq 'openbsd' && $signer_key_file =~ /^(openbsd)-(\d+)-pkg\.sec$/) {
		$key_type = $1;
		$num = $2;
		if ($num >= $OPENBSD_MIN_VERSION) {
		    print "DEBUG: Package signed with OpenBSD key: $signer_key_file\n" if ($debug_flag);
		    return 1;
		}
		else {
		    print "OpenBSD key $signer_key_file does not meet minimum version.\n";
		    return 0;
		}
	    }
	    else {
		print "Package signed with unrecognized key pattern: $signer_key_file\n";
		return 0;
	    }
	}
	else {
	    if ($signer_key_file =~ /^(\Q$DOMAINNAME\E)-(\d+)-pkg\.sec$/) {
		$key_type = $1;
		$num = $2;
		if ($num >= $SIGNIFY_MIN_YEAR) {
		    print "DEBUG: Plain/custom signed with own domain key: $signer_key_file\n" if ($debug_flag);
		    return 1;
		}
		else {
		    print "Domain key $signer_key_file does not meet minimum year.\n";
		    return 0;
		}
	    }
	    # Plain/custom with non-domain key
	    else {
		# For any other key, check if we should accept it
		# In install.pl this prompts, in distribute.pl this rejects
		if (can_accept_alternate_plain_key($signer_key_file)) {
		    print "Accepted alternate signing key.\n";
		    return 1;
		}
		else {
		    print "Rejected alternate signing key.\n";
		    return 0;
		}
	    }
	}
    }
    
    print "@errors";
    return 0;
}

# This differs in install.pl.
sub can_accept_alternate_plain_key {
    my ($key_file) = @_;
    print "Plain/custom signed with non-domain key: $key_file (rejected)\n";
    return 0;
}
